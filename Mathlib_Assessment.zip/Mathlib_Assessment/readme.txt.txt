All rights reserved.

Benjamin Vongtawan
benjamin.vongtawan@students.aie.edu.au

Run the executable to start the game.

Produced using VS2015 and a privately developed graphics library by : esmes@aie.edu.au.
Developed for the Intro to C++ topic while attending AIE Seattle (9/21/2016).

Splash Screen, title, and game background are edited by : benjamin.vongtawan@students.aie.edu.au.
